# Code Citations

## License: unknown
https://github.com/tleyden/docker/blob/74409db1f1a71c78443413a477f843a98e13b7d8/formattest/README.md

```
│
```


## License: MIT
https://github.com/marcusolsson/tui-go/blob/5004250eed0b877473eec1a09b0adfa24688169d/box_test.go

```
│
```


## License: unknown
https://github.com/wfy0508/Markdown_Notes/blob/e23d3be85219bd942ae94ae4aa8f68be8ef4efec/Java_notebook_part2.md

```
│
```


## License: unknown
https://github.com/rbonvall/carioca/blob/fd0eee4866c685de1a0d2579f7f193493605b5d8/carioca/card_area.py

```
│
                    │    └─────────────┘  └─────────
```


## License: unknown
https://github.com/davatorium/rofi/blob/6c38a49d543633e736d4e1653c0b02fe29e46ffd/mkdocs/docs/1.7.5/rofi-theme.5.markdown

```
│
                    │    └─────────────┘  └─────────
```


## License: unknown
https://github.com/tleyden/docker/blob/74409db1f1a71c78443413a477f843a98e13b7d8/formattest/README.md

```
│
                    │    └─────────────┘  └─────────
```


## License: MIT
https://github.com/marcusolsson/tui-go/blob/5004250eed0b877473eec1a09b0adfa24688169d/box_test.go

```
│
                    │    └─────────────┘  └─────────
```


## License: unknown
https://github.com/wfy0508/Markdown_Notes/blob/e23d3be85219bd942ae94ae4aa8f68be8ef4efec/Java_notebook_part2.md

```
│
                    │    └─────────────┘  └─────────
```


## License: unknown
https://github.com/rbonvall/carioca/blob/fd0eee4866c685de1a0d2579f7f193493605b5d8/carioca/card_area.py

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └
```


## License: unknown
https://github.com/davatorium/rofi/blob/6c38a49d543633e736d4e1653c0b02fe29e46ffd/mkdocs/docs/1.7.5/rofi-theme.5.markdown

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └
```


## License: unknown
https://github.com/tleyden/docker/blob/74409db1f1a71c78443413a477f843a98e13b7d8/formattest/README.md

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └
```


## License: MIT
https://github.com/marcusolsson/tui-go/blob/5004250eed0b877473eec1a09b0adfa24688169d/box_test.go

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └
```


## License: unknown
https://github.com/wfy0508/Markdown_Notes/blob/e23d3be85219bd942ae94ae4aa8f68be8ef4efec/Java_notebook_part2.md

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └
```


## License: unknown
https://github.com/rbonvall/carioca/blob/fd0eee4866c685de1a0d2579f7f193493605b5d8/carioca/card_area.py

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └───────────────────────────────────
```


## License: unknown
https://github.com/davatorium/rofi/blob/6c38a49d543633e736d4e1653c0b02fe29e46ffd/mkdocs/docs/1.7.5/rofi-theme.5.markdown

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └───────────────────────────────────
```


## License: unknown
https://github.com/tleyden/docker/blob/74409db1f1a71c78443413a477f843a98e13b7d8/formattest/README.md

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └───────────────────────────────────
```


## License: MIT
https://github.com/marcusolsson/tui-go/blob/5004250eed0b877473eec1a09b0adfa24688169d/box_test.go

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └───────────────────────────────────
```


## License: unknown
https://github.com/wfy0508/Markdown_Notes/blob/e23d3be85219bd942ae94ae4aa8f68be8ef4efec/Java_notebook_part2.md

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └───────────────────────────────────
```


## License: unknown
https://github.com/rbonvall/carioca/blob/fd0eee4866c685de1a0d2579f7f193493605b5d8/carioca/card_area.py

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └───────────────────────────────────────┘
```

##
```


## License: unknown
https://github.com/davatorium/rofi/blob/6c38a49d543633e736d4e1653c0b02fe29e46ffd/mkdocs/docs/1.7.5/rofi-theme.5.markdown

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └───────────────────────────────────────┘
```

##
```


## License: unknown
https://github.com/tleyden/docker/blob/74409db1f1a71c78443413a477f843a98e13b7d8/formattest/README.md

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └───────────────────────────────────────┘
```

##
```


## License: MIT
https://github.com/marcusolsson/tui-go/blob/5004250eed0b877473eec1a09b0adfa24688169d/box_test.go

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └───────────────────────────────────────┘
```

##
```


## License: unknown
https://github.com/wfy0508/Markdown_Notes/blob/e23d3be85219bd942ae94ae4aa8f68be8ef4efec/Java_notebook_part2.md

```
│
                    │    └─────────────┘  └─────────────┘   │
                    └───────────────────────────────────────┘
```

##
```

